#include <dlfcn.h>
#include <iostream>
#include <iomanip>
#include <cstring>
using CUresult=int;
using CUdevice=int;
using Init=CUresult(*)(unsigned int);
using Count=CUresult(*)(int*);
using Get=CUresult(*)(CUdevice*,int);
using Name=CUresult(*)(char*,int,CUdevice);
using Compute=CUresult(*)(int*,int*,CUdevice);
using Mem=CUresult(*)(size_t*,CUdevice);
int main(){
 void* h=dlopen("libcuda.so.1",RTLD_NOW|RTLD_LOCAL);
 if(!h){std::cerr<<"ERROR: CUDA driver library unavailable: "<<dlerror()<<"\n";return 2;}
 auto init=(Init)dlsym(h,"cuInit");auto count=(Count)dlsym(h,"cuDeviceGetCount");auto get=(Get)dlsym(h,"cuDeviceGet");auto name=(Name)dlsym(h,"cuDeviceGetName");auto cc=(Compute)dlsym(h,"cuDeviceComputeCapability");auto mem=(Mem)dlsym(h,"cuDeviceTotalMem_v2");
 if(!init||!count||!get||!name||!cc||!mem){std::cerr<<"ERROR: required CUDA Driver API symbol missing\n";dlclose(h);return 3;}
 int rc=init(0);if(rc){std::cerr<<"ERROR: cuInit returned "<<rc<<"\n";dlclose(h);return 4;}
 int n=0;rc=count(&n);if(rc){std::cerr<<"ERROR: cuDeviceGetCount returned "<<rc<<"\n";dlclose(h);return 5;}
 std::cout<<"CUDA Driver API initialized; GPUs="<<n<<"\n";
 for(int i=0;i<n;i++){CUdevice d;char nm[256]={};int major=0,minor=0;size_t bytes=0;
  if(get(&d,i)||name(nm,sizeof(nm),d)||cc(&major,&minor,d)||mem(&bytes,d)){std::cerr<<"ERROR: GPU "<<i<<" query failed\n";dlclose(h);return 6;}
  std::cout<<"GPU "<<i<<": "<<nm<<" | CC "<<major<<"."<<minor<<" | VRAM "<<std::fixed<<std::setprecision(1)<<(double)bytes/(1024*1024*1024)<<" GiB\n";
 }
 dlclose(h);return 0;
}
