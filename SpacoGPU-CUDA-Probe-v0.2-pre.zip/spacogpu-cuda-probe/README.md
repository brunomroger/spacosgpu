# SpacoGPU CUDA Driver API Probe v0.2-pre

Read-only CUDA Driver API initialization test. No kernel launches, overclock, VBIOS changes, or GPU allocations.

On HiveOS with g++:

```bash
g++ -O2 -std=c++17 -Wall -Wextra cuda_probe.cpp -ldl -o cuda_probe
./cuda_probe
```

This uses libcuda.so.1 dynamically; it does not need nvcc or CUDA headers. It verifies CUDA driver initialization, device enumeration, compute capability and VRAM capacity. It is **not** a mining benchmark or unlock.
