#!/usr/bin/env python3
"""SpacoGPU v0.3 - read-only NVIDIA + fl4shminer telemetry collector."""
import argparse
import csv
import datetime as dt
import os
from pathlib import Path
import re
import subprocess
import time

FIELDS = ['timestamp','gpu','name','hashrate_ths','power_w','efficiency_ths_w','temperature_c','core_mhz','memory_mhz','utilization_pct','memory_used_mib','pstate','hashrate_age_s']
HASH_RE = re.compile(r'Device\s*\[(\d+)\]\s*hashRate:\s*([\d.]+)\s*TH/s', re.I)
STAMP_RE = re.compile(r'^(\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2})')

def parse_hashrates(path):
    found = {}
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            for line in f:
                match = HASH_RE.search(line)
                if not match:
                    continue
                stamp = STAMP_RE.match(line)
                if not stamp:
                    continue
                try:
                    when = dt.datetime.strptime(stamp.group(1), '%Y/%m/%d %H:%M:%S')
                except ValueError:
                    continue
                found[int(match.group(1)) - 1] = (float(match.group(2)), when)
    except OSError as exc:
        print('AVISO: nao foi possivel ler log do minerador:', exc, flush=True)
    return found

def query_gpus():
    fields = 'index,name,pstate,utilization.gpu,clocks.gr,clocks.mem,power.draw,temperature.gpu,memory.used'
    result = subprocess.run(['nvidia-smi', '--query-gpu=' + fields, '--format=csv,noheader,nounits'], capture_output=True, text=True, timeout=15, check=True)
    rows = []
    for line in result.stdout.splitlines():
        values = [v.strip() for v in next(csv.reader([line]))]
        if len(values) == 9:
            rows.append(values)
    return rows

def number(raw):
    try:
        return float(raw)
    except (ValueError, TypeError):
        return None

def collect(log_path, max_age):
    now = dt.datetime.now()
    rates = parse_hashrates(log_path)
    records = []
    for gpu, name, pstate, util, core, mem, power, temp, used in query_gpus():
        index = int(gpu)
        watts = number(power)
        value, age = None, None
        if index in rates:
            candidate, recorded_at = rates[index]
            age = (now - recorded_at).total_seconds()
            if 0 <= age <= max_age:
                value = candidate
        records.append({
            'timestamp': now.isoformat(timespec='seconds'), 'gpu': index, 'name': name,
            'hashrate_ths': value, 'power_w': watts,
            'efficiency_ths_w': round(value / watts, 5) if value is not None and watts and watts > 0 else None,
            'temperature_c': number(temp), 'core_mhz': number(core), 'memory_mhz': number(mem),
            'utilization_pct': number(util), 'memory_used_mib': number(used), 'pstate': pstate,
            'hashrate_age_s': round(age, 1) if age is not None else None,
        })
    return records

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--log', default='/var/log/miner/fl4shminer/log.log')
    parser.add_argument('--out', default='logs/spacogpu_v03.csv')
    parser.add_argument('--interval', type=int, default=30)
    parser.add_argument('--count', type=int, default=10, help='0 = continuous')
    parser.add_argument('--max-age', type=int, default=90)
    args = parser.parse_args()
    if args.interval < 1 or args.count < 0 or args.max_age < 1:
        parser.error('interval >= 1, count >= 0, max-age >= 1')
    output = Path(args.out)
    output.parent.mkdir(parents=True, exist_ok=True)
    print('SpacoGPU v0.3 monitor read-only | Ctrl+C para encerrar', flush=True)
    i = 0
    try:
        while args.count == 0 or i < args.count:
            try:
                records = collect(args.log, args.max_age)
                new = not output.exists() or output.stat().st_size == 0
                with output.open('a', newline='', encoding='utf-8') as file:
                    writer = csv.DictWriter(file, fieldnames=FIELDS)
                    if new:
                        writer.writeheader()
                    writer.writerows(records)
                total_hash = sum(r['hashrate_ths'] for r in records if r['hashrate_ths'] is not None)
                total_w = sum(r['power_w'] for r in records if r['power_w'] is not None)
                complete = bool(records) and all(r['hashrate_ths'] is not None and r['power_w'] is not None for r in records)
                efficiency = f'{total_hash / total_w:.4f} TH/s/W' if complete and total_w else 'indisponivel (dados incompletos)'
                print(f"{dt.datetime.now():%H:%M:%S} | GPUs={len(records)} | Hash={total_hash:.2f} TH/s (parcial se faltarem GPUs) | W={total_w:.1f} | Eficiencia={efficiency}", flush=True)
            except (OSError, subprocess.SubprocessError, ValueError) as exc:
                print('ERRO de coleta:', exc, flush=True)
            i += 1
            if args.count == 0 or i < args.count:
                time.sleep(args.interval)
    except KeyboardInterrupt:
        print('\nMonitor encerrado.', flush=True)

if __name__ == '__main__':
    main()
